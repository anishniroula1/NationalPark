package com.techelevator.npgeek.model;

public interface SurveyResultDAO {
	
	public void saveSurvey(SurveyResult survey);
}
